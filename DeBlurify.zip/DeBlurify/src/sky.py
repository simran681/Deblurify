# import random

# # Genetic Algorithm Parameters
# POPULATION_SIZE = 10
# MAX_GENERATIONS = 50
# MUTATION_RATE = 0.1
# CROSSOVER_RATE = 0.7

# # Design variables (for our purposes, hypothetical limits for paper airplane design)
# MIN_WING_LENGTH = 5  # cm
# MAX_WING_LENGTH = 20 # cm
# MIN_BODY_LENGTH = 10 # cm
# MAX_BODY_LENGTH = 25 # cm

# # Step 1: Initialization - Create an initial population
# def create_individual():
#     wing_length = random.uniform(MIN_WING_LENGTH, MAX_WING_LENGTH)
#     body_length = random.uniform(MIN_BODY_LENGTH, MAX_BODY_LENGTH)
#     return [wing_length, body_length]

# population = [create_individual() for _ in range(POPULATION_SIZE)]

# # Step 2: Fitness Function - Hypothetical scenario where the fitness is the flying distance
# def fitness(individual):
#     wing_length, body_length = individual
#     # Hypothetical fitness calculation: the distance flown (the objective is to maximize this)
#     # This is a placeholder; in real scenarios, this would involve complex simulations/tests.
#     distance_flown = (wing_length * 0.5) + (body_length * 0.3)
#     return distance_flown

# # Genetic Algorithm main loop
# for generation in range(MAX_GENERATIONS):
#     # Step 3: Selection
#     # Select individuals for mating (using roulette wheel selection)
#     fitness_values = [fitness(ind) for ind in population]
#     total_fit = float(sum(fitness_values))
#     relative_fitness = [f/total_fit for f in fitness_values]
#     selected_indices = random.choices(range(len(population)), weights=relative_fitness, k=2)
    
#     parents = [population[i] for i in selected_indices]

#     # Step 4: Crossover
#     children = []
#     for i in range(2): # since we're selecting two parents
#         child = []
#         if random.random() < CROSSOVER_RATE:
#             crossover_point = random.randint(0,1) # as there are two variables
#             child = parents[i][:crossover_point] + parents[(i+1)%2][crossover_point:] # creating the child
#         else:
#             child = parents[i]
#         children.append(child)

#     # Step 5: Mutation
#     def mutate(ind):
#         new_ind = ind[:]
#         if random.random() < MUTATION_RATE:
#             mutate_point = random.randint(0,1) # choosing which design variable to mutate
#             if mutate_point == 0:
#                 new_ind[mutate_point] = random.uniform(MIN_WING_LENGTH, MAX_WING_LENGTH)
#             else:
#                 new_ind[mutate_point] = random.uniform(MIN_BODY_LENGTH, MAX_BODY_LENGTH)
#         return new_ind

#     children = [mutate(child) for child in children]

#     # Step 6: Replacement - Elitism: replacing worst ranked individuals from the population
#     population = sorted(population, key=lambda x: fitness(x), reverse=True)
#     population[-2:] = children

#     # Step 7: Termination check (Can be based on a fitness threshold or number of generations)
#     # Here we use the number of generations as the terminating condition

#     print(f"Generation {generation}: Best Fit: {fitness(population[0])}, Best Individual: {population[0]}")

# # Final result
# best_individual = max(population, key=lambda x: fitness(x))
# print(f"\nBest Individual after {MAX_GENERATIONS} generations: {best_individual}, Fitness: {fitness(best_individual)}")


import random
import plotly.express as px

# Genetic Algorithm Parameters
POPULATION_SIZE = 10
MAX_GENERATIONS = 50
MUTATION_RATE = 0.1
CROSSOVER_RATE = 0.7

# Design variables
MIN_WING_LENGTH = 5  # cm
MAX_WING_LENGTH = 20 # cm
MIN_BODY_LENGTH = 10 # cm
MAX_BODY_LENGTH = 25 # cm

# Step 1: Initialization - Create an initial population
def create_individual():
    wing_length = random.uniform(MIN_WING_LENGTH, MAX_WING_LENGTH)
    body_length = random.uniform(MIN_BODY_LENGTH, MAX_BODY_LENGTH)
    return [wing_length, body_length]

population = [create_individual() for _ in range(POPULATION_SIZE)]

# Step 2: Fitness Function
def fitness(individual):
    wing_length, body_length = individual
    # Hypothetical fitness calculation
    distance_flown = (wing_length * 0.5) + (body_length * 0.3)
    return distance_flown

# Genetic Algorithm main loop
for generation in range(MAX_GENERATIONS):
    # Selection, crossover, mutation, and replacement steps go here...
    # ... (rest of the GA loop)

    print(f"Generation {generation}: Best Fit: {fitness(population[0])}, Best Individual: {population[0]}")

# Final result
best_individual = max(population, key=lambda x: fitness(x))
print(f"\nBest Individual after {MAX_GENERATIONS} generations: {best_individual}, Fitness: {fitness(best_individual)}")

# Extract data for the 3D scatter plot
wing_lengths = [ind[0] for ind in population]
body_lengths = [ind[1] for ind in population]
distances = [fitness(ind) for ind in population]

# Create the interactive 3D scatter plot using plotly
fig = px.scatter_3d(x=wing_lengths, y=body_lengths, z=distances,
                    color=distances, color_continuous_scale='viridis',
                    labels={'x': 'Wing Length (cm)', 'y': 'Body Length (cm)', 'z': 'Distance Flown'},
                    title='Distance Flown vs. Wing Length and Body Length')

fig.show()
